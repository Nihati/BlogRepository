package com.ccl.dao;

import com.ccl.po.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-17-22:53
 */
public interface UserRepository extends JpaRepository<User,Long> {

    User findByUsernameAndPassword(String username,String password);
}
