package com.ccl.dao;

import com.ccl.po.Comment;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-20-21:52
 */
public interface CommentRepository extends JpaRepository<Comment,Long> {


    List<Comment> findByBlogIdAndParentCommentNull(Long blogId , Sort sort);

}
