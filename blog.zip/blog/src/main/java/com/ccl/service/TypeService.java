package com.ccl.service;

import com.ccl.po.Type;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;


/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-18-12:08
 */
public interface TypeService {

    Type saveType(Type type);

    Type getType(Long id);

    Page<Type> listType(Pageable pageable);

    List<Type> listType();

    List<Type> listTypeTop(Integer size);

    Type getTypeByName(String name);

    Type updateType(Long id, Type type);

    void deleteType(Long id);
}
