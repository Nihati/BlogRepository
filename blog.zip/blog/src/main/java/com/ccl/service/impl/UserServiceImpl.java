package com.ccl.service.impl;

import com.ccl.dao.UserRepository;
import com.ccl.po.User;
import com.ccl.service.UserService;
import com.ccl.util.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author 中律贰八
 * @desception User 和services层，用来处理用户登录
 * @create 2022-02-17-22:51
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User checkUser(String username, String password) {

        User user = userRepository.findByUsernameAndPassword(username, MD5Utils.code(password));
        return user;
    }



}
