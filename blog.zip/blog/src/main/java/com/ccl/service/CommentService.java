package com.ccl.service;

import com.ccl.po.Comment;
import org.w3c.dom.stylesheets.LinkStyle;

import java.util.List;

/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-20-21:47
 */
public interface CommentService {

    List<Comment> listCommentByLogId(Long blogId);

    Comment saveComment(Comment comment);
}
