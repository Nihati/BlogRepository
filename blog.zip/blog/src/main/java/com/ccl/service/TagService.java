package com.ccl.service;

import com.ccl.po.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;


/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-18-12:08
 */
public interface TagService {

    Tag saveTag(Tag tag);

    Tag getTag(Long id);

    Page<Tag> listTag(Pageable pageable);

    List<Tag> listTag(String ids);

    List<Tag> listTag();

    List<Tag> listTagTop(Integer size);

    Tag getTagByName(String name);

    Tag updateTag(Long id, Tag tag);

    void deleteTag(Long id);
}
