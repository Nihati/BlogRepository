package com.ccl.service;

import com.ccl.po.Blog;
import com.ccl.vo.BlogQuery;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-18-19:45
 */

public interface BlogService {

    Blog getBlog(Long id);

    Blog getAndConvert(Long id);//

    Page<Blog> listBlog(Pageable pageable, BlogQuery blog);

//    Page<Blog> listBlog(Pageable pageable, Blog blog);//查询一组数据，参数：分页和blog里的属性

    Page<Blog> listBlog(Pageable pageable);

    Page<Blog> listBlog(String query, Pageable pageable);

    Page<Blog> listBlog(Long tagId ,Pageable pageable);

    List<Blog> listRecommendBlogTop(Integer size);

    Map<String,List<Blog>> archiveBlog();

    Long countBlog();

    Blog saveBlog(Blog blog);

    Blog updateBlog(Long id, Blog blog);//根据id查询出来Blog更新，

    void deleteBlog(Long id);//根据主键来删除



}
