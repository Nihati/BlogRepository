package com.ccl.service;

import com.ccl.po.User;

/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-17-22:50
 */
public interface UserService {

    User checkUser(String username, String password);


}
