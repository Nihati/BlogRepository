package com.ccl.web;

import com.ccl.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author 中律贰八
 * @desception
 * @create 2022-02-21-17:26
 */
//@Controller
//public class ArchiveShowController {
//
//    @Autowired
//    BlogService blogService;
//
//
//    @GetMapping("/archives")
//    private String archives(Model model){
//
//        model.addAttribute("archiveMap",blogService.archiveBlog());
//        model.addAttribute("blogCount",blogService.countBlog());
//
//        return "archives";
//    }
//}




@Controller
public class ArchiveShowController {

    @Autowired
    private BlogService blogService;

    @GetMapping("/archives")
    public String archives(Model model) {
        model.addAttribute("archiveMap", blogService.archiveBlog());
        model.addAttribute("blogCount", blogService.countBlog());
        return "archives";
    }
}
